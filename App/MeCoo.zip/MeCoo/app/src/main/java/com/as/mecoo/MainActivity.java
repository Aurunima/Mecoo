package com.as.mecoo;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
//<a target="_blank" href="https://icons8.com/icon/53382/home-page">Home Page</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ProgressBar progressBar;
    private TextView progressText;
    int i = 101;
    private Button coolingNow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // set the id for the progressbar and progress text
        progressBar = findViewById(R.id.progress_bar);
//        progressRing = findViewById(R.id.)
        progressText = findViewById(R.id.progress_text);
        coolingNow = (Button) findViewById(R.id.cmd_cool);
        coolingNow.setOnClickListener(this);
    }
        @Override
        public void onClick(View view) {
            switch(view.getId()){
                case R.id.cmd_cool:
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // set the limitations for the numeric
                            // text under the progress bar

                            if (i > 95) {
                                progressText.setText("" + i+" F");
                                progressBar.setProgress(i);
                                i = i - 1;
                                handler.postDelayed(this, 1000);
                            } else {
                                handler.removeCallbacks(this);
                            }

                        }
                    }, 200);
            }
        }





}
