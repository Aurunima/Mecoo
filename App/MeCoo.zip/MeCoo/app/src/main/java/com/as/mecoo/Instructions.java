package com.as.mecoo;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Button;

public class Instructions extends AppCompatActivity implements View.OnClickListener {
    public static User user;
    private EditText habitText;
    private Button buttonToContinue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // hide the title bar
        setContentView(R.layout.activity_instructions);

        // edit text object to grab the habit description entered by user
//        habitText = findViewById(R.id.editPersonName);
        // set image btn objects for the setOnClickListener methods
        buttonToContinue = (Button) findViewById(R.id.buttonToContinue);
        buttonToContinue.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonToContinue:
                startActivity(new Intent(Instructions.this, MainActivity.class));

        }
    }



}

