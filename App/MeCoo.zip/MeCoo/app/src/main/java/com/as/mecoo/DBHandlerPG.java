package com.as.mecoo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;

/**
 * @author Lina Byland, Arina Karimova, Jesus Molinos
 * @version 2.0 May 8, 2022
 *
 * DBHandlerPG class was derived from the original SQLite.JDBC code. Android Studio does not
 * support the usage of JDBC files due to security issues.
 * This class tries to maintain the integrity of the SQLite database.
 */
public class DBHandlerPG extends SQLiteOpenHelper {

    /**
     * Creating a constant variables for our database.
     * Database name is set.
     */
    private static final String DB_NAME = "peaceGarden";

    /**
     * Int sets our database version.
     */
    private static final int DB_VERSION = 1;

    /**
     * creating a constructor for our database handler
     *
     * @param context
     */
    public DBHandlerPG(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    /**
     * onCreate method creates the database by running a sqlite query
     * Then a sqlite query is created.
     * The column names with their data types are set.
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db) {


        String sql = "CREATE TABLE USERS" +
                "(UserID INTEGER PRIMARY KEY, " +
                "Username TEXT NOT NULL, " +
                "EmailAddress TEXT NOT NULL, " +
                "Password TEXT NOT NULL)";

        db.execSQL(sql);



    }






    /** Counts how many Users are in the database.
     *
     * @return the total amount of users in the database.
     */
    protected int countUsers(){
        int userCount;

        try {
            SQLiteDatabase db = this.getReadableDatabase();

            Cursor totalUsers = db.rawQuery("SELECT COUNT(*) FROM USERS", null);

            totalUsers.moveToFirst();

            userCount = totalUsers.getInt(0);

            db.close();

        } catch (Exception e){
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            return -1;
        }

        return userCount;

    }

    /** Creates a new row for a user in the USERS table of the database.
     *  It takes a User object as the parameter.
     *
     * @param newUser the new user to be added to the database
     * @return true if the entry was created successfully, false if it wasn't.
     */
    public boolean createUser(User newUser){

        try {
            SQLiteDatabase db = this.getWritableDatabase();

            String sql = "INSERT INTO USERS(Username,EmailAddress,Password) "
                    + "VALUES('"+ newUser.getUsername() + "', '" + newUser.getEmailAddress()
                    + "', '" + newUser.getPassword() + "');";

            db.execSQL(sql);
            db.close();

        } catch (Exception e){
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            return false;
        }

        return true;
    }

    /** Creates a new row for a user in the USERS table of the database.
     *  It creates the row from a username, emailAddress, and password.
     *
     * @param username the new user's username
     * @param emailAddress the new user's email address
     * @param password the new user's password
     * @return true if the user was created successfully, false if it wasn't.
     */
    public boolean createUser(String username, String emailAddress, String password){

        try {
            SQLiteDatabase db = this.getWritableDatabase();

            String sql = "INSERT INTO USERS(Username,EmailAddress,Password) "
                    + "VALUES('"+ username + "', '" + emailAddress + "', '" + password + "');";

            db.execSQL(sql);
            db.close();

        } catch (Exception e){
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            return false;
        }

        return true;
    }










    /** Updates a User in the database.
     *
     * @param updatedUser the User with the new information that needs to be
     * updated in the database.
     * @return true if it was updated, false if there was an error
     */
    protected boolean updateUser(User updatedUser){

        try {
            SQLiteDatabase db = this.getWritableDatabase();

            String sql = "UPDATE USERS SET Username = '"
                    + updatedUser.getUsername() +"', EmailAddress = '"
                    + updatedUser.getEmailAddress() + "', Password = '"
                    + updatedUser.getPassword() + "' WHERE UserID =" + updatedUser.getId() + ";";

            db.execSQL(sql);
            db.close();

        } catch (Exception e){
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            return false;
        }

        return true;

    }



    /** Checks if the login information is correct.
     *
     * @param emailAddress the user's email address
     * @param password the user's password
     * @return true if the information exists and it is exact, false if it isn't.
     */

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkLogin(String emailAddress, String password){
        if(this.getUserFromLoginInfo(emailAddress,password).getEmailAddress() == "default")
            return false;
        else
            return true;
    }

    /** Returns a User object from the login information.
     *
     * This can be used as a "login". It returns the information of a specific user associated
     * with the email address and password.
     * If either the email address or password aren't found or don't match the one stored
     * in the database, then it will return a User object
     * initialized with the default constructor. This means that to verify that the user
     * was able to log in, the program should check if
     * the username, emailaddress, and password are equal to "default".
     *
     * @param emailAddress The user's email address.
     * @param password The user's password.
     * @return A user object associated with the email address and password.
     * In the case of error, the user will be the "default" user.
     *
     */

    @RequiresApi(api = Build.VERSION_CODES.O)
    public User getUserFromLoginInfo(String emailAddress, String password){
        int userID = this.countUsers() + 1;
        User curUser = new User(userID);

        try {
            SQLiteDatabase db = this.getReadableDatabase();

            Cursor getUsers = db.rawQuery("SELECT * FROM USERS WHERE EmailAddress = '"
                    + emailAddress + "' AND " +
                    "Password = '" + password + "';", null);

            getUsers.moveToFirst();

            if(getUsers.isNull(0)){
                System.out.println("Login failed");
            }else{

                userID = getUsers.getInt(0);
                curUser = new User(userID, getUsers.getString(1), getUsers.getString(2),
                        getUsers.getString(3));
                System.out.println("Login successful");
            }

            db.close();

        } catch (Exception e){
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }

        return curUser;
    }



    /** Returns an ArrayList of User objects with all the users in the database.
     *  It sets the habits in the User object.
     *
     *  Useful for debugging.
     *
     * @return an ArrayList of User objects with all the users in the database,
     * with their respective habits.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    protected ArrayList<User> getAllUsers(){
        ArrayList<User> users = new ArrayList<>();
        User curUser;

        try {
            SQLiteDatabase db = this.getReadableDatabase();

            Cursor getUsers = db.rawQuery("SELECT * FROM USERS", null);

            getUsers.moveToFirst();


            while(!getUsers.isAfterLast() && getUsers.getColumnCount() > 2){
                int userID = getUsers.getInt(0);
                //System.out.println("New USER ID: " + userID);
                curUser = new User(userID, getUsers.getString(1), getUsers.getString(2), getUsers.getString(3));

                users.add(curUser);

                getUsers.moveToNext();

            }

            db.close();

        } catch (Exception e){
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }


        return users;
    }

    /**
     * onUpgrade method is called to check if the table already exists.
     * @param db
     * @param oldVersion
     * @param newVersion
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + "FLOWERS");

        onCreate(db);
    }
}