package com.as.mecoo;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
public class user_registration extends AppCompatActivity{
    // creating variables for our edittext, button and dbhandler
    private EditText userNameEdt, emailAddressEdt, passwordEdt;
    private Button continueBtn;
    public static DBHandlerPG dbHandler;

    /**
     * @RequiresAPI is needed to support the minimum required OS for Android. If the user has O
     * or higher this code will execute.
     * The navigation toolbar is created but hidden. The variables are initiated and the
     * DBHandler Class is created and passed the context.
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        userNameEdt = findViewById(R.id.editUserName);
        emailAddressEdt = findViewById(R.id.editEmailAddress);
        passwordEdt = findViewById(R.id.editPassword);
        continueBtn = findViewById(R.id.sign_in);

        dbHandler = new DBHandlerPG(user_registration.this);

        /**
         * @RequiredAPI see above.
         * The Continue button onClickListener is created.
         * Based on the login info, a user and habit are built.
         */
        continueBtn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)

            @Override
            public void onClick(View view) {

                // will build a user and habit based  on login info
                User curUser;


                // below line is to get data from all edit text fields.
                String userName = userNameEdt.getText().toString();
                String emailAddress = emailAddressEdt.getText().toString();
                String password = passwordEdt.getText().toString();

                // validating if the text fields are empty or not.
                // This does not appear to do anything...
                if (userName.isEmpty() && emailAddress.isEmpty() && password.isEmpty()) {
                    Toast.makeText(user_registration.this,
                            "Please enter all fields..", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (dbHandler.checkLogin(emailAddress, password)){
                    curUser = dbHandler.getUserFromLoginInfo(emailAddress, password);
                    curUser.db = dbHandler;

                }else{
                    //
                    int userID = dbHandler.countUsers() + 1;

                    curUser = new User(userID, userName, emailAddress, password);
                    curUser.db = dbHandler;
                    dbHandler.createUser(userName, emailAddress, password);


                    Instructions.user = curUser;
                    Intent intent = new Intent(user_registration.this, Instructions.class);
                    startActivity(intent);
                }


            }
        });
}}
