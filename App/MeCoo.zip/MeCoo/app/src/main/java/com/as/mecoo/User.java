package com.as.mecoo;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;

/**
 * @author Lina Byland, Arina Karimova, Jesus Molinos
 * @version 2.0 May 8, 2022
 * Class User, holds all of the user's information.
 */

public class User {
    private String username;
    private String emailAddress;

    private String bio;
    protected String password;
    protected int id;
    protected DBHandlerPG db;



    /** The default constructor for User.
     *  Sets the username to 'default' and the email to 'default@emailaddress.com'.
     */
    public User(int userID){
        this.username = "default";
        this.emailAddress = "default";
//        this.activeHabits = new ArrayList<>();
        this.id = userID;
    }

    /** The constructor for User used for loading the User from the database.
     *  While the other constructors set the ID number of the User internally,
     *  this constructor takes it as a parameter.
     *
     * @param userID The ID number of the User. The ID number refers to the row number
     * in the database.
     * @param username The User's username.
     * @param emailAddress The User's email address.
     * @param password The User's password.
     */
    public User(int userID, String username, String emailAddress, String password){
        this.username = username;
        this.emailAddress = emailAddress;
        this.password = password;
//        this.activeHabits = new ArrayList<>();
        this.id = userID;
    }


    /** Checks whether or not the password attempt is the same as
     * the password stored in the User object.
     *
     * @param passAttempt
     * @return password
     */
    public boolean checkPassword(String passAttempt){
        return password == passAttempt;
    }



    /** Gets the username.
     *
     * @return the User's username.
     */
    public String getUsername() {
        return username;
    }

    /** Gets the email address.
     *
     * @return the User's email address.
     */
    public String getEmailAddress() {
        return emailAddress;
    }







    /** Gets the Password
     *
     * @return password.
     */
    public String getPassword(){
        return password;
    }



    /** Gets the ID
     *
     * @return ID.
     */
    public int getId() {
        return id;
    }


}
